﻿<?php include 'header.php'; ?>

<div class="container">
	<br>
	<div style="margin-left:40px" class="row">
		<div class="bigtitle">Kullanıcı Girişi</div>
	</div>
<br>
	 <?php  

                  if (@$_GET['durum']=="basarisizgiris") {?>

                    <div class="alert alert-danger">
                      <strong>Hata!</strong> Kullanıcı Ad Şifre Yanlış.
                    </div>

                  <?php }?>

                    <form action="nedmin/netting/islem.php" method="POST" role="form">

<div class="col-md-12">

                      <div class="form-group col-md-6">
                       <input type="text" class="form-control" name="kullanici_mail" id="username" placeholder="Kullanıcı Adınız (Mail Adresiniz)">
                     </div>
</div>
<div class="col-md-12">
                     <div class="form-group col-md-6">
                       <input type="password" class="form-control" name="kullanici_password" id="password" placeholder="Şifreniz">
                     </div>
</div>
<div class="col-md-12">

                     <div style="margin-left:15px;"  class="form-group">
                       <button type="submit" name="kullanicigiris" class="btn btn-default btn-red btn-sm">Giriş Yap</button>
                     </div>

                     Hesabınız Yoksa <a style="color:red" href="register">Kayıt</a>&nbsp;Olunuz...
</div>


                   </form>

<div class="spacer"></div>
</div>

<?php include 'footer.php'; ?>