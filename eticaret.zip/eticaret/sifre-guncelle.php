﻿<?php include 'header.php'; ?>

<div class="container">
	<div class="row">
		
	</div>

	<form action="nedmin/netting/islem.php" method="POST" class="form-horizontal checkout" role="form">
		<div class="row">
			<div class="col-md-6">
				<div class="title-bg">
					<div class="title">Şifrenizi  Güncelleyin</div>
				</div>

				<?php 

				if (@$_GET['durum']=="farklisifre") {?>

					<div class="alert alert-danger">
						<strong>Hata!</strong> Girdiğiniz şifreler eşleşmiyor.
					</div>
					
				<?php } elseif (@$_GET['durum']=="eksiksifre") {?>

					<div class="alert alert-danger">
						<strong>Hata!</strong> Şifreniz minimum 6 karakter uzunluğunda olmalıdır.
					</div>
					
				<?php } elseif (@$_GET['durum']=="mukerrerkayit") {?>

					<div class="alert alert-danger">
						<strong>Hata!</strong> Bu kullanıcı daha önce kayıt edilmiş.
					</div>
					
				<?php } elseif (@$_GET['durum']=="basarisiz") {?>

					<div class="alert alert-danger">
						<strong>Hata!</strong> Kayıt Yapılamadı Sistem Yöneticisine Danışınız.
					</div>
					
				<?php }elseif  (@$_GET['duzenleme']=="ok") {?>
					<div class="alert alert-success">
						<strong>Güzel :)</strong> Düzenleme Başarılı.
					</div>
				<?php }elseif  (@$_GET['durum']=="sifredegisti") {?>
					<div class="alert alert-success">
						<strong>Güzel :)</strong> Şifreniz Başarıyla Güncellendi.
					</div>
				<?php } elseif (@$_GET['durum']=="no") {?>

					<div class="alert alert-danger">
						<strong>Hata!</strong> Hata şifreniz Güncellenemedi Site Yöneticisiyle Görüşün.
					</div>
					
				<?php }elseif (@$_GET['duzenleme']=="no") { ?>
					<div class="alert alert-danger">
						<strong>Hata !</strong> Düzenleme Başarısız.
					</div>
				<?php }elseif (@$_GET['eskisifre']=="hata") { ?>
					<div class="alert alert-danger">
						<strong>Hata !</strong> Eski Sifreniz Hatalı.
					</div>
				<?php }elseif (@$_GET['durum']=="eskisifrehata") { ?>
					<div class="alert alert-danger">
						<strong>Hata !</strong> Eski Sifreniz Hatalı.
					</div>
				<?php }elseif (@$_GET['durum']=="sifreleruyusmuyor") { ?>
					<div class="alert alert-danger">
						<strong>Hata !</strong> Şifreleriniz Uyuşmuyor.
					</div>
				<?php }elseif (@$_GET['durum']=="ok") { ?>
					<div class="alert alert-success">
						<strong>Başarılı !</strong> Şifreniz Başarıyla Güncellendi.
					</div>
				<?php }elseif (@$_GET['durum']=="no") { ?>
					<div class="alert alert-danger">
						<strong>Hata !</strong> Şifreniz Güncellenmedi.
					</div>
				<?php } ?>

				<input type="hidden" name="kullanici_id" value="<?php echo $kullanicicek{'kullanici_id'} ?>">

				<div class="form-group">
					<label class="col-sm-12" for="first-name">Eski Şifre<span class="required"></span>
					</label>
					<div class="col-sm-12">
						<input  type="password" class="form-control" name="kullanici_eskipassword" placeholder="Eski Sifrenizi Giriniz">
					</div>
				</div>


				<div class="form-group  dob">
					<label class="col-sm-12" for="first-name">Yeni Şifre<span class="required"></span>
					</label>
					<div class="col-sm-6">
						<input type="password" class="form-control" name="kullanici_passwordone" placeholder="Yeni Şifrenizi Giriniz" >
					</div>
					<div class="col-sm-6">
						<input type="password" class="form-control" name="kullanici_passwordtwo" placeholder="Yeni Şifrenizi Tekrar Giriniz"  >
					</div>

				</div>



				<button type="submit" name="kullanicisifreguncelle" class="btn btn-default btn-red">Şifreyi Değiştir</button>
			</div>

		</div>
	</div>
</form>
<div class="spacer"></div>
</div>

<?php include 'footer.php'; ?>