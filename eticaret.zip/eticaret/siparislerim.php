﻿<?php include 'header.php'; ?>
<?php
$siparis_detaysor=$db->prepare("SELECT * FROM siparis_detay ");
$siparis_detaysor->execute(array());
$siparis_detaycek=$siparis_detaysor->fetch(PDO::FETCH_ASSOC);
?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-title-wrap">
				<div class="page-title-inner">
					<div class="row">
						<div class="col-md-12">
							<div class="bigtitle">Sipariş Bilgilerim</div>
							<p >Vermiş olduğunuz siparişlerinizi listeliyorsunuz</p>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>

	<form action="nedmin/netting/islem.php" method="POST" class="form-horizontal checkout" role="form">
		<div class="row">
			<div class="col-md-12">
				<div class="title-bg">
					<div class="title">Sipariş Bilgileri</div>
				</div>

				<div class="table-responsive">
					<table class="table table-bordered chart">
						<thead>
							<tr>
								
								<th>Sipariş No</th>
								<th>Tarih</th>
								<th>Tutar</th>
								<th>Ödeme Tip</th>
								
								<th>Durum</th>
								
								
								
							</tr>
						</thead>
						<tbody>

							<?php 
							$kullanici_id=$kullanicicek['kullanici_id'];
							$siparissor=$db->prepare("SELECT * FROM siparis where kullanici_id=:id");
							$siparissor->execute(array(
								'id' => $kullanici_id
							));

							while($sipariscek=$siparissor->fetch(PDO::FETCH_ASSOC)) {?>
								<tr>
									<td><?php echo $sipariscek['siparis_id']; ?></td>
									<td><?php echo $sipariscek['siparis_zaman']; ?></td>
									<td><?php echo $sipariscek['siparis_toplam']; ?></td>
									<td><?php echo $sipariscek['siparis_tip']; ?></td>
								
									<td><center>   
										<?php if ($sipariscek['siparis_durum']==0) { echo "Ödeme Bekleniyor"?>

										<?php }elseif($sipariscek['siparis_durum']==1) { echo "Ödeme Yapıldı"; ?></td>
									<?php } ?>
									</center><td>
										<a href="siparis-detay.php?siparis_id=<?php echo $sipariscek['siparis_id'] ?>">
											<input class="btn btn-xs btn-success" name="siparis_detay" value="Sipariş Detayını Görüntüle">
										</a>
									</td>
									
									
								</tr>

							<?php } ?>

						</tbody>
					</table>
				</div>


			</form>








		</div>

	</div>
</div>

<div class="spacer"></div>
</div>

<?php include 'footer.php'; ?>