<?php include '../netting/baglan.php' ?>

<?php include 'header.php' ?>
<?php
$slider_id=$_GET['slider_id'];

$slidersor=$db->prepare("SELECT * FROM slider where slider_id='$slider_id'");
$slidersor->execute();
$slidercek=$slidersor->fetch(PDO::FETCH_ASSOC);
?>  
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
   

    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div  class="x_title">
              <h2>Slider Düzenleme İşlemleri</h2>
              <ul class="nav navbar-right panel_toolbox">
                <div align="right">
                  <td  class=" "><a href="index.php"><button class="btn btn-round btn-primary"><i class="fa fa-mail-reply " aria-hidden="true"></i>  Anasayfaya Dön </button></a></td>
                  <td  class=" "><a href="slider.php"><button class="btn btn-round btn-danger"><i class="fa fa-undo " aria-hidden="true"></i> Geriye Dön </button></a></td>

                </div>

              </ul>

              <div class="clearfix"></div>
              <small> 

                <?php 

                if (@$_GET['durum']=="ok") { ?>

                  <h7 style="color:green" class="page-subhead-line">Slider Başarıyla Düzenlendi</h7>


                <?php } elseif (@$_GET['durum']=="no") { ?>

                  <h7 style="color:red"class="page-subhead-line">Slider Düzenleme Gerçekleştirilemedi </h7>


                


                <?php } ?>






              </small>
            </div>

            <div class="x_content">


             <form enctype="multipart/form-data" action="../netting/islem.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
              <input type="hidden" name="slider_id" value="<?php echo $slidercek['slider_id']; ?>">

              <div class="form-group ">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name"> Yüklü Olan Resim  <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                 <img style="width: 490px;height: 200px;" src="../<?php echo $slidercek['slider_resimyol'] ?>">
               </div>

               <input type="hidden" name="slider_resimyol" value="<?php echo $slidercek['slider_resimyol']; ?>">

             </div>

             <div class="form-group ">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Resim Seç  <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="slider_resimyol" type="file"  id="first-name"  class="form-control col-md-7 col-xs-12" value="<?php echo $slidercek['slider_resimyol'] ?>">
              </div>
            </div>

            <div class="form-group ">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Ad  <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="slider_ad" type="text" id="first-name"     class="form-control col-md-7 col-xs-12" value="<?php echo $slidercek['slider_ad'] ?>">
              </div>
            </div>
 <!-- Ck Editör Başlangıç -->

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Detay <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">

                  <textarea  class="ckeditor" id="editor1" name="slider_detay" ><?php echo $slidercek['slider_detay']; ?></textarea>
                </div>
              </div>

              <script type="text/javascript">

               CKEDITOR.replace( 'editor1',

               {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash',

                forcePasteAsPlainText: true

              } 

              );

            </script>

            <!-- Ck Editör Bitiş -->
            <div  class="form-group ">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Linki <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="slider_link" type="text" id="first-name"     class="form-control col-md-7 col-xs-12"value="<?php echo $slidercek['slider_link'] ?>">
              </div>
            </div>
            <div  class="form-group ">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Sıra <span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input name="slider_sira" type="text" id="first-name"     class="form-control col-md-7 col-xs-12"value="<?php echo $slidercek['slider_sira'] ?>">
              </div>
            </div>


            <div  class="form-group ">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Durum <span class="required">*</span>
              </label>
              <div class="col-md-2 col-sm-9 col-xs-12">
                <select class="form-control" name="slider_durum">
                 <option value="1"<?php echo $slidercek['slider_durum']== '1' ? 'selected=""' : ''; ?>>Aktif</option>

                 <option value="0"<?php echo $slidercek['slider_durum']== '0' ? 'selected=""' : ''; ?>>Pasif</option>
               </select>
             </div>
           </div>




           <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

            <button name="sliderduzenle" type="submit" class="btn btn-danger">Slider Düzenle</button>
          </div>





        </form>


      </div>

    </div>
  </div>
</div>
</div>
</div>
</div>
<!-- /page content -->

<?php include 'footer.php' ?>