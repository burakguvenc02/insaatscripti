<?php 

include 'header.php'; 

//Belirli veriyi seçme işlemi
$urunsor=$db->prepare("SELECT * FROM urun order by urun_id DESC");
$urunsor->execute();


?>


<!-- page content -->
<div class="right_col" role="main">
  <div class="">

    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Ürün Listesi<small>

             <?php 

             if (@$_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

            <?php } elseif (@$_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

            <?php }elseif (@$_GET['ekleme']=="basarili") {?>

              <b style="color:green">Ürün Ekleme Başarılı...</b>

            <?php }elseif (@$_GET['ekleme']=="basarısız") {?>

              <b style="color:red">Ürün Ekleme Başarısız...</b>

            <?php }

            ?>
            <?php 

            if (@$_GET['sil']=="ok") {?>

              <b style="color:green;">Ürün Başarıyla Silindi...</b>

            <?php } elseif (@$_GET['sil']=="no") {?>

              <b style="color:red;">Ürün Silinemedi...</b>

            <?php }

            ?>

          </small></h2>
          <ul class="nav navbar-right panel_toolbox">



          </ul>
          <div class="clearfix"></div>
          <div align="right">
            <a href="urun-ekle.php"><button class="btn btn-success btn-xs">Ürün  Ekle</button></a>

          </div>
        </div>
        <div class="x_content">


          <!-- Div İçerik Başlangıç -->

          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th> No</th>
                <th> Ürün Kodu</th>
                <th>Ürün Ad</th>
                <th>Ürün Stok</th>
                <th>Ürün Fiyatı</th>
                <th>Ürün Resim</th>
                <th><center>Öne Çek</center></th>
                <th>Ürün Durum</th>
                <th></th>


                <th></th>
                <th></th>
              </tr>
            </thead>

            <tbody>

              <?php 
              $say=0; 
              while($uruncek=$urunsor->fetch(PDO::FETCH_ASSOC)) { $say++?>


                <tr>
                  <td width="20"><?php echo $say ?></td>
                  <td width="20"><?php echo $uruncek['urun_id'] ?></td>
                  <td><?php echo $uruncek['urun_ad'] ?></td>
                  <td><?php echo $uruncek['urun_stok'] ?></td>
                  <td><?php echo $uruncek['urun_fiyat'] ?> </td>
                  <td><a href="urun-galeri.php?urun_id=<?php echo $uruncek['urun_id'] ?>"><button class="btn-xs btn-success">Resim İşlemleri</button></a></td>

                  <td>

                    <?php if ($uruncek['urun_onecikar']==0) {?>
                      <center><a href="../netting/islem.php?urun_id=<?php echo $uruncek['urun_id'] ?>&urun_one=1&urun_onecikar=ok"><button class="btn btn-success btn-xs">Gösteriliyor</button></a></center>
                    <?php }elseif($uruncek['urun_onecikar']==1) { ?>

                     <center><a href="../netting/islem.php?urun_id=<?php echo $uruncek['urun_id'] ?>&urun_one=0&urun_onecikar=ok"><button style="font-size: 100%" class="btn btn-warning btn-xs">Kaldır</button></a></center>

                   <?php } ?>




                 </td>
                 <td>

                  <?php if ($uruncek['urun_durum']==0) {?>
                    <center><button class="btn btn-danger btn-xs">Ürün Durumu Pasif</button></center>
                  <?php }elseif($uruncek['urun_durum']==1) { ?>

                   <center><button style="font-size: 100%" class="btn btn-success btn-xs">Ürün Durumu Aktif</button></center>

                 <?php } ?>




               </td>


               <td><center><a href="urun-duzenle.php?urun_id=<?php echo $uruncek['urun_id'] ?>"><button class="btn btn-primary btn-xs">Düzenle</button></a></center></td>



               <td><center><a href="../netting/islem.php?urun_id=<?php echo $uruncek['urun_id'];?>&urunsil=ok"><button class="btn btn-danger btn-xs"><i class="fa fa-trash">&nbsp;</i>Sil</button></a></center></td>
             </tr>



           <?php  }

           ?>


         </tbody>
       </table>

       <!-- Div İçerik Bitişi -->


     </div>
   </div>
 </div>
</div>




</div>
</div>
<!-- /page content -->

<?php include 'footer.php'; ?>
