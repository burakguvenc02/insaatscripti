<?php 

include 'header.php'; 

//Belirli veriyi seçme işlemi
$bankasor=$db->prepare("SELECT * FROM banka order by banka_id ASC");
$bankasor->execute();


?>


<!-- page content -->
<div class="right_col" role="main">
  <div class="">

    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Banka Listesi<small>

              <?php 

              if (@$_GET['durum']=="ok") {?>

                <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif (@$_GET['durum']=="no") {?>

                <b style="color:red;">İşlem Başarısız...</b>

              <?php }elseif (@$_GET['ekle']=="ok") {?>

                <b style="color:green;">Banka Başarıyla Eklenmiştir...</b>

              <?php }?>
              <?php 

              if (@$_GET['sil']=="ok") {?>

                <b style="color:green;">Banka Başarıyla Silindi...</b>

              <?php } elseif (@$_GET['sil']=="no") {?>

                <b style="color:red;">Banka Silinemedi...</b>

              <?php }

              ?>

            </small></h2>
            <ul class="nav navbar-right panel_toolbox">



            </ul>
            <div class="clearfix"></div>
            <div align="right">
              <a href="banka-ekle.php"><button class="btn btn-success btn-xs">Banka  Ekle</button></a>

            </div>
          </div>
          <div class="x_content">


            <!-- Div İçerik Başlangıç -->

            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th> No</th>
                  <th> Ad</th>
                  <th>Banka IBAN</th>
                  <th>Banka Hesap AdSoyad</th>
                  <th>Banka Durum</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>

              <tbody>

                <?php 
                $say=0; 
                while($bankacek=$bankasor->fetch(PDO::FETCH_ASSOC)) { $say++?>


                  <tr>
                    <td width="20"><?php echo $say ?></td>
                    <td><?php echo $bankacek['banka_ad'] ?></td>
                    <td><?php echo $bankacek['banka_iban'] ?></td>
                    <td><?php echo $bankacek['banka_hesapadsoyad'] ?></td>
                    <td>

                      <?php if ($bankacek['banka_durum']==0) {?>
                        <center><button class="btn btn-danger btn-xs">banka Durumu Pasif</button></center>
                      <?php }elseif($bankacek['banka_durum']==1) { ?>

                       <center><button style="font-size: 100%" class="btn btn-success btn-xs">banka Durumu Aktif</button></center>

                     <?php } ?>




                   </td>
                   <td><center><a href="banka-duzenle.php?banka_id=<?php echo $bankacek['banka_id'] ?>"><button class="btn btn-primary btn-xs">Düzenle</button></a></center></td>



                   <td><center><a href="../netting/islem.php?banka_id=<?php echo $bankacek['banka_id'];?>&bankasil=ok"><button class="btn btn-danger btn-xs"><i class="fa fa-trash">&nbsp;</i>Sil</button></a></center></td>
                 </tr>



               <?php  }

               ?>


             </tbody>
           </table>

           <!-- Div İçerik Bitişi -->


         </div>
       </div>
     </div>
   </div>




 </div>
</div>
<!-- /page content -->

<?php include 'footer.php'; ?>
