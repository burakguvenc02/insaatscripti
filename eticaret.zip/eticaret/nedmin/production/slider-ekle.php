<?php include '../netting/baglan.php' ?>

<?php include 'header.php' ?>
<?php
$slidersor=$db->prepare("SELECT * FROM slider where slider_id=:id");
$slidersor->execute(array('id' => 0));
$slidercek=$slidersor->fetch(PDO::FETCH_ASSOC);
?>  
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Slider Ekleme Sayfası</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Anahtar Kelimeleriniz">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Ara</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div  class="x_title">
                    <h2>Slider Ekleme İşlemleri</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <div align="right">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     </div>
                     
                    </ul>

                    <div class="clearfix"></div>
                  <small> 

<?php 

if (@$_GET['durum']=="ok") { ?>
  
<h7 style="color:green" class="page-subhead-line">Slider Başarıyla Kaydedildi</h7>


      <?php } elseif (@$_GET['durum']=="no") { ?>
  
<h7 style="color:red"class="page-subhead-line">Slider Ekleme Gerçekleştirilemedi </h7>


    <?php } else { ?>

<h7 style="color: blue"class="page-subhead-line">Sliderlerinizi Bu Sayfadan Ekleyebilirsiniz</h7>


<?php } ?>






               </small>
                  </div>

                  <div class="x_content">

                  
                       <form enctype="multipart/form-data" action="../netting/islem.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">

                     <div class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Resim Seç  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="slider_resimyol" type="file"  id="first-name"   class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Ad  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="slider_ad" type="text" id="first-name"   class="form-control col-md-7 col-xs-12" placeholder="Slider Adını Giriniz">
                        </div>
                      </div>
 <!-- Ck Editör Başlangıç -->

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Detay <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">

                  <textarea  class="ckeditor" id="editor1" name="slider_detay" ></textarea>
                </div>
              </div>

              <script type="text/javascript">

               CKEDITOR.replace( 'editor1',

               {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash',

                forcePasteAsPlainText: true

              } 

              );

            </script>

            <!-- Ck Editör Bitiş -->

                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Linki <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="slider_link" type="text" id="first-name"   class="form-control col-md-7 col-xs-12"placeholder="Slider Linki Giriniz">
                        </div>
                      </div>
                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="slider_sira" type="text" id="first-name"   class="form-control col-md-7 col-xs-12"value="0">
                        </div>
                      </div>
                       <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Slider Durum <span class="required">*</span>
                        </label>
                       <div class="col-md-2 col-sm-9 col-xs-12">
                          <select class="form-control" name="slider_durum">
                            <option value="1">Aktif</option>
                            <option value="0">Pasif</option>
                           
                          </select>
                       </div>
                      </div>
                      
                    
                      
                      <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          
                          <button name="sliderayarkaydet" type="submit" class="btn btn-danger">Slider Ekle</button>
                        </div>
                     
                      
                      
                    

                    </form>


                  </div>
               
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

     <?php include 'footer.php' ?>