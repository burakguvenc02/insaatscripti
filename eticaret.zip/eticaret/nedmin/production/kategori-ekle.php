<?php 

include 'header.php'; 
?>

<!-- page content -->
<div class="right_col" role="main">
  <div class="">

    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Kategori Ekleme Sayfası<small>

              <?php 

              if (@$_GET['durum']=="ok") {?>

                <b style="color:green;">Kategori Başarıyla Eklendi...</b>

              <?php }elseif (@$_GET['ekleme']=="basarısız") {?>

                <b style="color:red;">Kategori Eklenemedi...</b>

              <?php }

              ?>


            </small></h2>
            <div align="right">
             <a href="kategori.php"><button  type="submit" class="btn btn-primary"><i class="fa fa-reply-all"></i>&nbsp;Kategori Tablosuna Geri Dön</button></a></div>
             <div class="clearfix"></div>
           </div>
           <div class="x_content">
            <br />

            <!-- / => en kök dizine çık ... ../ bir üst dizine çık -->
            <form action="../netting/islem.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12">Üst Kategori Seç</label>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <select class="select2_single form-control" name="kategori_ust" required="" tabindex="-1">
                    

                    <option value="0">Üst Kategori</option>
                    

                    <?php      

                    $ustkategorisor = $db->prepare("select * from kategori where kategori_ust=:kategori_ust $aranan order by kategori_sira ASC  ");
                    $ustkategorisor->execute(array('kategori_ust' => 0)); ?>

                    <?php while ($ustkategoricek=$ustkategorisor->fetch(PDO::FETCH_ASSOC)){?>
                      <option value="<?php echo $ustkategoricek['kategori_id'] ?>"></"><?php echo $ustkategoricek['kategori_ad'] ?></option>

                    <?php } ?>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Adı<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="first-name" name="kategori_ad" placeholder="Kategori Adını Giriniz"   class="form-control col-md-7 col-xs-12">
                </div>
              </div>

              <!-- Ck Editör Başlangıç -->

              


              <!-- Ck Editör Bitiş -->

              
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Sırası <span class="required">*</span>
                </label>
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <input type="number" id="first-name" name="kategori_sira" placeholder="Sırayı Giriniz" class="form-control col-md-7 col-xs-12">
                </div>

              </div>





              <div  class="form-group ">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Durum <span class="required">*</span>
                </label>
                <div class="col-md-2 col-sm-9 col-xs-12">
                  <select class="form-control" name="kategori_durum">
                   <option value="1">Aktif</option>

                   <option value="0">Pasif</option>
                 </select>
               </div>
             </div>




             <div class="ln_solid"></div>
             <div class="form-group">
              <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <button type="submit" name="kategorikaydet" class="btn btn-success">Kategoriyi Ekle</button>
              </div>
            </div>

          </form>



        </div>
      </div>
    </div>
  </div>



  <hr>
  <hr>
  <hr>



</div>
</div>
<!-- /page content -->

<?php include 'footer.php'; ?>
