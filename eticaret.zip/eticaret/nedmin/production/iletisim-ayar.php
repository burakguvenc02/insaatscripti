<?php include '../netting/baglan.php' ?>

<?php include 'header.php' ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ayarlar</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Anahtar Kelimeleriniz">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Ara</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div  class="x_title">
                    <h2>Arayüz Ayarlar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <div align="right">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     </div>
                     
                    </ul>

                    <div class="clearfix"></div>
                  <small> 

<?php 

if (@$_GET['durum']=="ok") { ?>
  
<h7 style="color:green" class="page-subhead-line">Güncelleme Başarıyla Kaydedildi</h7>


      <?php } elseif (@$_GET['durum']=="no") { ?>
  
<h7 style="color:red"class="page-subhead-line">Güncelleme Gerçekleştirilemedi </h7>


    <?php } else { ?>

<h7 style="color: blue"class="page-subhead-line"> Arayüz Ayarlarını Bu Sayfadan Düzenleyebilirsiniz</h7>


<?php } ?>









                  </small>
                  </div>

                  <div class="x_content">

                  
                       <form action="../netting/islem.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">

                      <div class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">GSM No<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_gsm" type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_gsm'] ?>">
                        </div>
                      </div>

                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Telefon Numara <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_tel" type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_tel'] ?>">
                        </div>
                      </div>
                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Faks<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_faks" type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_faks'] ?>">
                        </div>
                      </div>
                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Mail Adresi <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_mail" type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12"value="<?php echo $ayarcek['ayar_mail'] ?>">
                        </div>
                      </div>
                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Adres Bilgileri <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_adres" type="text" id="first-name" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_adres'] ?>">
                        </div>
                      </div>
                        <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name"> İl  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_il" type="text" id="first-name"  class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_il'] ?>">
                        </div>
                      </div>
                       <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name"> İlçe  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_ilce" type="text" id="first-name"  class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_ilce'] ?>">
                        </div>
                      </div>
                      <div  class="form-group ">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name"> Mesai Saatleri  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input name="ayar_mesai" type="text" id="first-name"  class="form-control col-md-7 col-xs-12" value="<?php echo $ayarcek['ayar_mesai'] ?>">
                        </div>
                      </div>
                      
                      <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          
                          <button name="iletisimayarkaydet" type="submit" class="btn btn-success">Değişiklikleri Kaydet</button>
                        </div>
                     
                      
                      
                    

                    </form>


                  </div>
               
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

     <?php include 'footer.php' ?>