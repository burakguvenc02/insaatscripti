          <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
              <h3>General</h3>
              <ul class="nav side-menu">
                <li><a href="index.php"><i class="fa fa-home"></i> Anasayfa </a></li>



                <li><a><i class="fa fa-cogs"></i> Ayarlar  <span class="fa fa-cogs"></span></a>
                  <ul class="nav child_menu">
                    <li><a href="genel-ayar.php">Genel Ayarlar</a></li>
                    <li><a href="iletisim-ayar.php">İletişim Ayarları</a></li>
                    <li><a href="api-ayar.php">Api Ayarları</a></li>
                    <li><a href="sosyal-ayar.php">Sosyal Ayarlar</a></li>
                    <li><a href="mail-ayar.php">Mail Ayarları</a></li>
                  </ul>
                </li>




                <li><a href="hakkimizda.php"><i class="fa fa-info"></i> Hakkımızda</a></li>
                <li><a href="kullanici.php"><i class="fa fa-user"></i> Kullanıcılar </a></li>
                <li><a href="menu.php"><i class="fa fa-list"></i> Menülerimiz </a></li>
                <li><a href="kategori.php"><i class="fa fa-list"></i> Kategori </a></li>
                <li><a href="urunler.php"><i class="fa fa-cart-plus"></i> Ürünlerimiz </a></li>
                <li><a href="slider.php"><i class="fa fa-image"></i> Slider</a></li>
                <li><a href="yorum.php"><i class="fa fa-comments"></i>Kullanıcı Yorumları</a></li>
                <li><a href="banka.php"><i class="fa fa-bank"></i>Bankalar</a></li>
              </ul>






            </div>



          </div>