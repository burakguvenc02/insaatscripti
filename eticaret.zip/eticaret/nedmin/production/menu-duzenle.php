<?php 

include 'header.php'; 

$menusor=$db->prepare("SELECT * FROM menu where menu_id=:id");
$menusor->execute(array(
  'id' => $_GET['menu_id']
));

$menucek=$menusor->fetch(PDO::FETCH_ASSOC);

?>

<!-- page content -->
<div class="right_col" role="main">
  <div class="">

    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Menü Düzenleme Sayfası<small>

              <?php 

              if (@$_GET['duzenleme']=="ok") {?>

                <b style="color:green;">Menü Başarıyla Düzenlendi...</b>

              <?php } elseif (@$_GET['duzenleme']=="no") {?>

                <b style="color:red;">Menü Düzenlenemedi...</b>

              <?php }

              ?>


            </small></h2>
            <div align="right">
             <a href="menu.php"><button  type="submit" class="btn btn-primary"><i class="fa fa-reply-all"></i>&nbsp;Menü Tablosuna Geri Dön</button></a></div>
             <div class="clearfix"></div>
           </div>
           <div class="x_content">
            <br />

            <!-- / => en kök dizine çık ... ../ bir üst dizine çık -->
            <form action="../netting/islem.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
              <input type="hidden" name="menu_id" value="<?php echo $menucek['menu_id'] ?>">

  <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Sayfa Linki<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input disabled="" type="text" id="first-name" name="menu_ad" value="<?php echo $ayarcek['ayar_siteurl'] ?>sayfa-<?php echo seo($menucek['menu_ad']) ?>"   class="form-control col-md-7 col-xs-12">
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Menu Adı<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="first-name" name="menu_ad" value="<?php echo $menucek['menu_ad'] ?>"   class="form-control col-md-7 col-xs-12">
                </div>
              </div>

              <!-- Ck Editör Başlangıç -->

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Menü Detayı <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">

                  <textarea  class="ckeditor" id="editor1" name="menu_detay"><?php echo $menucek['menu_detay']; ?></textarea>
                </div>
              </div>

              <script type="text/javascript">

               CKEDITOR.replace( 'editor1',

               {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash',

                forcePasteAsPlainText: true

              } 

              );

            </script>

            <!-- Ck Editör Bitiş -->

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Menu Linki<span class="required">*</span>
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="text" id="first-name" name="menu_url" value="<?php echo $menucek['menu_url'] ?>"   class="form-control col-md-7 col-xs-12">
              </div>

            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Menü Sırası <span class="required">*</span>
              </label>
              <div class="col-md-1 col-sm-3 col-xs-12">
                <input type="number" id="first-name" name="menu_sira" value="<?php echo $menucek['menu_sira'] ?>"   class="form-control col-md-7 col-xs-12">
              </div>

            </div>





            <div  class="form-group ">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Menü Durum <span class="required">*</span>
              </label>
              <div class="col-md-2 col-sm-9 col-xs-12">
                <select class="form-control" name="menu_durum">
                 <option value="1"<?php echo $menucek['menu_durum']== '1' ? 'selected=""' : ''; ?>>Aktif</option>

                 <option value="0"<?php echo $menucek['menu_durum']== '0' ? 'selected=""' : ''; ?>>Pasif</option>
               </select>
             </div>
           </div>




           <div class="ln_solid"></div>
           <div class="form-group">
            <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
              <button type="submit" name="menuduzenle" class="btn btn-success">Menüyü Güncelle</button>
            </div>
          </div>

        </form>



      </div>
    </div>
  </div>
</div>



<hr>
<hr>
<hr>



</div>
</div>
<!-- /page content -->

<?php include 'footer.php'; ?>
