<?php
error_reporting(0);
ob_start();
session_start();
date_default_timezone_set('Europe/Istanbul');

include 'baglan.php';
include '../production/fonksiyon.php';




if (isset($_POST['kullanicikaydet'])) {

	
	echo $kullanici_adsoyad=htmlspecialchars($_POST['kullanici_adsoyad']); echo "<br>";
	echo $kullanici_mail=htmlspecialchars($_POST['kullanici_mail']); echo "<br>";

	echo $kullanici_passwordone=$_POST['kullanici_passwordone']; echo "<br>";
	echo $kullanici_passwordtwo=$_POST['kullanici_passwordtwo']; echo "<br>";


	if ($kullanici_passwordone==$kullanici_passwordtwo) {


// Başlangıç

		$kullanicisor=$db->prepare("select * from kullanici where kullanici_mail=:mail");
		$kullanicisor->execute(array(
			'mail' => $kullanici_mail
		));

			//dönen satır sayısını belirtir
		$say=$kullanicisor->rowCount();



		if ($say==0) {

				//md5 fonksiyonu şifreyi md5 şifreli hale getirir.
			$password=md5($kullanici_passwordone);

			$kullanici_yetki=1;

			//Kullanıcı kayıt işlemi yapılıyor...
			$kullanicikaydet=$db->prepare("INSERT INTO kullanici SET
				kullanici_adsoyad=:kullanici_adsoyad,
				kullanici_mail=:kullanici_mail,
				kullanici_password=:kullanici_password,
				kullanici_gsm=:kullanici_gsm,
				kullanici_tc=:kullanici_tc,
				kullanici_yetki=:kullanici_yetki
				");
			$insert=$kullanicikaydet->execute(array(
				'kullanici_gsm' =>$_POST['kullanici_gsm'],
				'kullanici_tc' =>$_POST['kullanici_tc'],
				'kullanici_adsoyad' => $kullanici_adsoyad,
				'kullanici_mail' => $kullanici_mail,
				'kullanici_password' => $password,
				'kullanici_yetki' => $kullanici_yetki
			));

			if ($insert) {


				header("Location:../../index.php?durum=loginbasarili");


				//Header("Location:../production/genel-ayarlar.php?durum=ok");

			} else {


				header("Location:../../register.php?durum=basarisiz");
			}

		} else {

			header("Location:../../register.php?durum=mukerrerkayit");



		}




		// Bitiş




		if (strlen($kullanici_passwordone)>=6) {

		}else{

			header("Location:../../register.php?durum=eksiksifre");


		}





	}else{

		header("Location:../../register.php?durum=farklisifre");


	}


}





if (isset($_POST['kullanicigiris'])) {


	
	echo $kullanici_mail=htmlspecialchars($_POST['kullanici_mail']); 
	echo $kullanici_password=md5($_POST['kullanici_password']); 



	$kullanicisor=$db->prepare("select * from kullanici where kullanici_mail=:mail and kullanici_yetki=:yetki and kullanici_password=:password and kullanici_durum=:durum");
	$kullanicisor->execute(array(
		'mail' => $kullanici_mail,
		'yetki' => 1,
		'password' => $kullanici_password,
		'durum' => 1
	));


	$say=$kullanicisor->rowCount();



	if ($say==1) {

		echo $_SESSION['userkullanici_mail']=$kullanici_mail;

		header("Location:../../");
		exit;
		




	} else {


		header("Location:../../giris.php?durum=basarisizgiris");

	}


}



if (isset($_POST['kullanicihesapduzenle'])) {
	$kullanici_id=$_POST['kullanici_id'];
	//Tablo güncelleme işlemi kodları...
	$kullanıcıduzenle=$db->prepare("UPDATE kullanici SET
		kullanici_adsoyad=:adsoyad,
		kullanici_tc=:tc,
		kullanici_gsm=:gsm,
		kullanici_adres=:adres,
		kullanici_il=:il,
		kullanici_ilce=:ilce
		where kullanici_id={$_POST['kullanici_id']} ");

	$update=$kullanıcıduzenle->execute(array(
		'adsoyad' => $_POST['kullanici_adsoyad'],
		'tc' => $_POST['kullanici_tc'],
		'gsm' => $_POST['kullanici_gsm'],
		'adres' => $_POST['kullanici_adres'],
		'il' => $_POST['kullanici_il'],
		'ilce' => $_POST['kullanici_ilce']
	));


	if ($update) {

		header("Location:../../hesabim.php?duzenleme=ok");

	} else {

		header("Location:../../hesabim.php?duzenleme=no");
	}
	
}





if (isset($_POST['admingiris'])) {

	$kullanici_mail=$_POST['kullanici_mail'];
	$kullanici_password=md5($_POST['kullanici_password']);

	$kullanicisor=$db->prepare("SELECT * FROM kullanici where kullanici_mail=:mail and kullanici_password=:password and kullanici_yetki=:yetki");
	$kullanicisor->execute(array(
		'mail' => $kullanici_mail,
		'password' => $kullanici_password,
		'yetki' => 5
	));

	echo $say=$kullanicisor->rowCount();

	if ($say==1) {

		$_SESSION['kullanici_mail']=$kullanici_mail;
		header("Location:../production/index.php");
		exit;



	} else {

		header("Location:../production/login.php?durum=no");
		exit;
	}
	

}
if (isset($_POST['kullanıcıduzenle'])) {
	$kullanici_id=$_POST['kullanici_id'];
	//Tablo güncelleme işlemi kodları...
	$kullanıcıduzenle=$db->prepare("UPDATE kullanici SET
		kullanici_tc=:tc,
		kullanici_adsoyad=:adsoyad,
		
		kullanici_durum=:durum
		where kullanici_id={$_POST['kullanici_id']} ");

	$update=$kullanıcıduzenle->execute(array(
		'tc' => $_POST['kullanici_tc'],
		'adsoyad' => $_POST['kullanici_adsoyad'],
		
		'durum' => $_POST['kullanici_durum']
	));


	if ($update) {

		header("Location:../production/kullanici-duzenle.php?kullanici_id=$kullanici_id&duzenleme=ok");

	} else {

		header("Location:../production/kullanici-duzenle.php?kullanici_id=$kullanici_id&duzenleme=no");
	}
	
}

if(@$_GET['kullanicisil']=="ok"){
	$sil=$db->prepare("DELETE From kullanici where kullanici_id=:id");
	$kontrol=$sil->execute(array(
		'id'=> $_GET['kullanici_id']
	));

	if ($kontrol) {

		header("Location:../production/kullanici.php?sil=ok");

	} else {

		header("Location:../production/kullanici.php?sil=no");
	}
	
}





if (isset($_POST['genelayarkaydet'])) {
	
	//Tablo güncelleme işlemi kodları...
	$ayarkaydet=$db->prepare("UPDATE ayar SET
		ayar_title=:ayar_title,
		ayar_description=:ayar_description,
		ayar_keywords=:ayar_keywords,
		ayar_siteurl=:ayar_siteurl,
		ayar_author=:ayar_author
		WHERE ayar_id=0");

	$update=$ayarkaydet->execute(array(
		'ayar_title' => $_POST['ayar_title'],
		'ayar_description' => $_POST['ayar_description'],
		'ayar_keywords' => $_POST['ayar_keywords'],
		'ayar_siteurl' => $_POST['ayar_siteurl'],
		'ayar_author' => $_POST['ayar_author']
	));


	if ($update) {

		header("Location:../production/genel-ayar.php?durum=ok");

	} else {

		header("Location:../production/genel-ayar.php?durum=no");
	}
	
}



if (isset($_POST['iletisimayarkaydet'])) {
	
	//Tablo güncelleme işlemi kodları...
	$ayarkaydet=$db->prepare("UPDATE ayar SET
		ayar_tel=:ayar_tel,
		ayar_gsm=:ayar_gsm,
		ayar_faks=:ayar_faks,
		ayar_mail=:ayar_mail,
		ayar_ilce=:ayar_ilce,
		ayar_il=:ayar_il,
		ayar_adres=:ayar_adres,
		ayar_mesai=:ayar_mesai
		WHERE ayar_id=0");

	$update=$ayarkaydet->execute(array(
		'ayar_tel' => $_POST['ayar_tel'],
		'ayar_gsm' => $_POST['ayar_gsm'],
		'ayar_faks' => $_POST['ayar_faks'],
		'ayar_mail' => $_POST['ayar_mail'],
		'ayar_ilce' => $_POST['ayar_ilce'],
		'ayar_il' => $_POST['ayar_il'],
		'ayar_adres' => $_POST['ayar_adres'],
		'ayar_mesai' => $_POST['ayar_mesai']
	));


	if ($update) {

		header("Location:../production/iletisim-ayar.php?durum=ok");

	} else {

		header("Location:../production/iletisim-ayar.php?durum=no");
	}
	
}


if (isset($_POST['apiayarkaydet'])) {
	
	//Tablo güncelleme işlemi kodları...
	$ayarkaydet=$db->prepare("UPDATE ayar SET
		
		ayar_analystic=:ayar_analystic,
		ayar_maps=:ayar_maps,
		ayar_zopim=:ayar_zopim
		WHERE ayar_id=0");

	$update=$ayarkaydet->execute(array(

		'ayar_analystic' => $_POST['ayar_analystic'],
		'ayar_maps' => $_POST['ayar_maps'],
		'ayar_zopim' => $_POST['ayar_zopim']
	));


	if ($update) {

		header("Location:../production/api-ayar.php?durum=ok");

	} else {

		header("Location:../production/api-ayar.php?durum=no");
	}
	
}


if (isset($_POST['hakkimizdakaydet'])) {
	
	//Tablo güncelleme işlemi kodları...

	/*

	copy paste işlemlerinde tablo ve işaretli satır isminin değiştirildiğinden emin olun!!!

	*/
	$ayarkaydet=$db->prepare("UPDATE hakkimizda SET
		hakkimizda_baslik=:hakkimizda_baslik,
		hakkimizda_icerik=:hakkimizda_icerik,
		hakkimizda_video=:hakkimizda_video,
		hakkimizda_vizyon=:hakkimizda_vizyon,
		hakkimizda_misyon=:hakkimizda_misyon
		WHERE hakkimizda_id=0");

	$update=$ayarkaydet->execute(array(
		'hakkimizda_baslik' => $_POST['hakkimizda_baslik'],
		'hakkimizda_icerik' => $_POST['hakkimizda_icerik'],
		'hakkimizda_video' => $_POST['hakkimizda_video'],
		'hakkimizda_vizyon' => $_POST['hakkimizda_vizyon'],
		'hakkimizda_misyon' => $_POST['hakkimizda_misyon']
	));


	if ($update) {

		header("Location:../production/hakkimizda.php?durum=ok");

	} else {

		header("Location:../production/hakkimizda.php?durum=no");
	}
	
}


if (isset($_POST['menuduzenle'])) {
	$menu_id=$_POST['menu_id'];
	$menu_seourl=seo($_POST['menu_ad']);
	//Tablo güncelleme işlemi kodları...
	$menuduzenle=$db->prepare("UPDATE menu SET
		menu_ad=:ad,
		menu_detay=:detay,
		menu_url=:url,
		menu_sira=:sira,
		menu_seourl=:menu_seourl,
		menu_durum=:durum
		where menu_id={$_POST['menu_id']} ");
	$update=$menuduzenle->execute(array(
		'ad' => $_POST['menu_ad'],
		'detay' => $_POST['menu_detay'],
		'url' => $_POST['menu_url'],
		'sira' => $_POST['menu_sira'],
		'menu_seourl' => $menu_seourl,
		'durum' => $_POST['menu_durum']
	));


	if ($update) {

		header("Location:../production/menu-duzenle.php?menu_id=$menu_id&duzenleme=ok");

	} else {

		header("Location:../production/menu-duzenle.php?menu_id=$menu_id&duzenleme=no");
	}
	
}


if(@$_GET['menusil']=="ok"){
	$sil=$db->prepare("DELETE From menu where menu_id=:id");
	$kontrol=$sil->execute(array(
		'id'=> $_GET['menu_id']
	));

	if ($kontrol) {

		header("Location:../production/menu.php?sil=ok");

	} else {

		header("Location:../production/menu.php?sil=no");
	}
	
}


if (isset($_POST['menukaydet'])) {


	$menu_seourl=seo($_POST['menu_ad']);
	$menukaydet=$db->prepare("INSERT into menu SET  

		menu_ad=:ad,
		menu_url=:url,
		menu_detay=:detay,
		menu_sira=:sira,
		menu_seourl=:menu_seourl,
		menu_durum=:durum
		");
	$insert=$menukaydet->execute(array(

		'ad' =>$_POST['menu_ad'],
		'url' =>$_POST['menu_url'],
		'detay' =>$_POST['menu_detay'],
		'sira' =>$_POST['menu_sira'],
		'menu_seourl' =>$menu_seourl,
		'durum' =>$_POST['menu_durum'],
	));
	if ($insert) {
		header("Location:../production/menu.php?durum=ok");
	} else {
		header("Location:../production/menu-ekle.php?durum=no");
	}
} 

if (isset($_POST['logoduzenle'])) {


	if($_FILES['ayar_logo']["size"] > 0){
		$uploads_dir = '../../resimg';
		@$tmp_name = $_FILES['ayar_logo']['tmp_name'];
		@$name = $_FILES['ayar_logo']['name'];
		$rondom = rand(1000, 9000);
		$resimyol = substr($uploads_dir, 3).'/'.$rondom.'-'.$name;

		@move_uploaded_file($tmp_name, "$uploads_dir/$rondom-$name");


		$logoduzenle=$db->prepare("UPDATE ayar SET 
			ayar_logo=:logo
			WHERE ayar_id=0");
		$update=$logoduzenle->execute(array(
			'logo' =>$resimyol,

		));



	} if ($update) {
		$logo_sil=$_POST['eski_yol'];
		unlink("../../resimg/$logo_sil");

		header("Location:../production/genel-ayar.php?ayar_id=$ayar_id&durum=ok");
	} else {
		header("Location:../production/genel-ayar.php?durum=no");
	}
}

if (isset($_POST['sliderayarkaydet'])) {

	$uploads_dir = '../uploads';
	@$tmp_name = $_FILES['slider_resimyol']['tmp_name'];
	@$name = $_FILES['slider_resimyol']['name'];
	$rondom = rand(1000, 9000);
	$resimyol = substr($uploads_dir, 3).'/'.$rondom.'-'.$name;
	@move_uploaded_file($tmp_name, "$uploads_dir/$rondom-$name");



	$sliderayarkaydet=$db->prepare("INSERT into slider SET  
		slider_ad=:ad,
		slider_link=:link,
		slider_sira=:sira,
		slider_durum=:durum,
		slider_detay=:detay,
		slider_resimyol=:resimyol
		");
	$insert=$sliderayarkaydet->execute(array(
		'ad' =>$_POST['slider_ad'],
		'link' =>$_POST['slider_link'],
		'sira' =>$_POST['slider_sira'],
		'durum' =>$_POST['slider_durum'],
		'detay' =>$_POST['slider_detay'],
		'resimyol' =>$resimyol,
	));
	if ($insert) {
		header("Location:../production/slider.php?durum=ok");
	} else {
		header("Location:../production/slider-ekle.php?durum=no");
	}
} 


if (isset($_POST['sliderduzenle'])) {

	if($_FILES['slider_resimyol']["size"] > 0){

		$uploads_dir = '../uploads';
		@$tmp_name = $_FILES['slider_resimyol']['tmp_name'];
		@$name = $_FILES['slider_resimyol']['name'];
		$rondom = rand(1000, 9000);
		$resimyol = substr($uploads_dir, 3).'/'.$rondom.'-'.$name;
		@move_uploaded_file($tmp_name, "$uploads_dir/$rondom-$name");


		$sliderduzenle=$db->prepare("UPDATE slider SET 
			slider_ad=:ad,
			slider_link=:link,
			slider_sira=:sira,
			slider_durum=:durum,
			slider_detay=:detay,
			slider_resimyol=:resimyol
			WHERE slider_id={$_POST['slider_id']}");
		$update=$sliderduzenle->execute(array(
			'ad' =>$_POST['slider_ad'],
			'link' =>$_POST['slider_link'],
			'sira' =>$_POST['slider_sira'],
			'detay' =>$_POST['slider_detay'],
			'durum' =>$_POST['slider_durum'],
			'resimyol' =>$resimyol,

		));
		$slider_id=$_POST['slider_id'];
		if ($update) {
			$slider_sil=$_POST['slider_resimyol'];
			unlink("../$slider_sil");

			header("Location:../production/slider-duzenle.php?slider_id=$slider_id&durum=ok");
		} else {
			header("Location:../production/slider-duzenle.php?durum=no");
		}


	}else{
		$sliderduzenle=$db->prepare("UPDATE slider SET 
			slider_ad=:ad,
			slider_link=:link,
			slider_sira=:sira,
			slider_durum=:durum
			WHERE slider_id={$_POST['slider_id']}");
		$update=$sliderduzenle->execute(array(
			'ad' =>$_POST['slider_ad'],
			'link' =>$_POST['slider_link'],
			'sira' =>$_POST['slider_sira'],
			'durum' =>$_POST['slider_durum']

		));

		$slider_id=$_POST['slider_id'];
		if ($update) {

			header("Location:../production/slider-duzenle.php?slider_id=$slider_id&durum=ok");
		} else {
			header("Location:../production/slider-duzenle.php?durum=no");
		}

	} 


}


if (@$_GET['slidersil']=="ok") {



	$sil=$db->prepare("DELETE from slider where slider_id=:slider_id");
	$kontrol=$sil->execute(array(
		'slider_id' => $_GET['slider_id']
	));
	if ($kontrol) {
		$slider_sil=$_GET['sliderresimsil'];
		unlink("../$slider_sil");
		header("Location:../production/slider.php?durum=ok");
	} else {
		header("Location:../production/slider.php?durum=no");
	}
} 


if (isset($_POST['kategoriduzenle'])) {
	$kategori_id=$_POST['kategori_id'];
	$kategori_seourl=seo($_POST['kategori_ad']);
//Tablo güncelleme işlemi kodları...
	$kategoriduzenle=$db->prepare("UPDATE kategori SET
		kategori_ad=:ad,
		kategori_sira=:sira,
		kategori_seourl=:kategori_seourl,
		kategori_durum=:durum
		where kategori_id={$_POST['kategori_id']} ");
	$update=$kategoriduzenle->execute(array(
		'ad' => $_POST['kategori_ad'],
		'sira' => $_POST['kategori_sira'],
		'kategori_seourl' => $kategori_seourl,
		'durum' => $_POST['kategori_durum']
	));


	if ($update) {

		header("Location:../production/kategori-duzenle.php?kategori_id=$kategori_id&duzenleme=ok");

	} else {

		header("Location:../production/kategori-duzenle.php?kategori_id=$kategori_id&duzenleme=no");
	}

}

if (isset($_POST['kategorikaydet'])) {
	$kategori_seourl=seo($_POST['kategori_ad']);
//Tablo güncelleme işlemi kodları...
	$kategorikaydet=$db->prepare("INSERT into kategori SET
		kategori_ad=:ad,
		kategori_sira=:sira,
		kategori_seourl=:kategori_seourl,
		kategori_ust=:a,
		altkategori_id=:c,
		kategori_durum=:durum
		");
	$kaydet=$kategorikaydet->execute(array(
		'ad' => $_POST['kategori_ad'],
		'sira' => $_POST['kategori_sira'],
		'kategori_seourl' => $kategori_seourl,
		'a' => $_POST['kategori_ust'],
		'c' => $_POST['altkategori_id'],
		'durum' => $_POST['kategori_durum']
	));


	if ($kaydet) {

		header("Location:../production/kategori.php?ekle=ok");

	} else {

		header("Location:../production/kategori-ekle.php?ekleme=basarısız");
	}

}


if(@$_GET['kategorisil']=="ok"){
	$sil=$db->prepare("DELETE From kategori where kategori_id=:id");
	$kontrol=$sil->execute(array(
		'id'=> $_GET['kategori_id']
	));

	if ($kontrol) {

		header("Location:../production/kategori.php?sil=ok");

	} else {

		header("Location:../production/kategori.php?sil=no");
	}
	
}



if(@$_GET['urunsil']=="ok"){
	$sil=$db->prepare("DELETE From urun where urun_id=:id");
	$kontrol=$sil->execute(array(
		'id'=> $_GET['urun_id']
	));

	if ($kontrol) {

		header("Location:../production/urunler.php?sil=ok");

	} else {

		header("Location:../production/urunler.php?sil=no");
	}

}





if (isset($_POST['urunduzenle'])) {
	$urun_id=$_POST['urun_id'];
	$urun_seourl=seo($_POST['urun_ad']);
//Tablo güncelleme işlemi kodları...
	$urunekle=$db->prepare("UPDATE  urun SET
		kategori_id=:id,
		urun_ad=:ad,
		urun_detay=:detay,
		urun_fiyat=:fiyat,
		urun_video=:video,
		urun_keyword=:urun_keyword,
		urun_stok=:urun_stok,		
		urun_seourl=:urun_seourl,
		altkategori_id=:aid,
		urun_onecikar=:urun_onecikar,
		urun_durum=:durum
		
		where urun_id={$_POST['urun_id']}");
	$update=$urunekle->execute(array(
		'id' => $_POST['kategori_id'],
		'ad' => $_POST['urun_ad'],
		'detay' => $_POST['urun_detay'],
		'fiyat' => $_POST['urun_fiyat'],
		'video' => $_POST['urun_video'],
		'urun_keyword' => $_POST['urun_keyword'],
		'urun_stok' => $_POST['urun_stok'],
		'urun_seourl' => $urun_seourl,
		'aid' => $_POST['altkategori_id'],
		'urun_onecikar' => $_POST['urun_onecikar'],
		'durum' => $_POST['urun_durum'],
		
	));

	if ($update) {

		header("Location:../production/urun-duzenle.php?urun_id=$urun_id&duzenleme=ok");

	} else {

		header("Location:../production/urun-duzenle.php?urun_id=$urun_id&duzenleme=no");
	}
}



if (isset($_POST['urunekle'])) {
	$kategori_seourl=seo($_POST['urun_ad']);
//Tablo güncelleme işlemi kodları...
	$kategorikaydet=$db->prepare("INSERT into urun SET
		kategori_id=:kategori_id,
		urun_ad=:urun_ad,
		urun_detay=:urun_detay,
		urun_fiyat=:urun_fiyat,
		urun_video=:urun_video,
		urun_keyword=:urun_keyword,
		urun_stok=:urun_stok,
		urun_seourl=:urun_seourl,
		urun_durum=:urun_durum
		");
	$kaydet=$kategorikaydet->execute(array(
		'kategori_id' => $_POST['kategori_id'],
		'urun_ad' => $_POST['urun_ad'],
		'urun_detay' => $_POST['urun_detay'],
		'urun_fiyat' => $_POST['urun_fiyat'],
		'urun_video' => $_POST['urun_video'],
		'urun_keyword' => $_POST['urun_keyword'],
		'urun_stok' => $_POST['urun_stok'],
		'urun_seourl' => $kategori_seourl,
		'urun_durum' => $_POST['urun_durum']
	));


	if ($kaydet) {

		header("Location:../production/urunler.php?ekleme=basarili");

	} else {

		header("Location:../production/urun-ekle.php?ekleme=basarısız");
	}

}



if (isset($_POST['yorumkaydet'])) {



	$gelen_url=$_POST["gelen_url"];

	$yorumkaydet=$db->prepare("INSERT into yorumlar SET  

		
		yorum_detay=:detay,
		kullanici_id=:kullanici_id,
		urun_id=:urun_id
		
		");
	$insert=$yorumkaydet->execute(array(

		'detay' =>$_POST['yorum_detay'],
		'kullanici_id' =>$_POST['kullanici_id'],
		'urun_id' =>$_POST['urun_id'],

	));
	if ($insert) {
		header("Location:$gelen_url?durum=ok");
	} else {
		header("Location:$gelen_url?durum=no");
	}
} 




if (isset($_POST['yorumduzenle'])) {
	$yorum_id=$_POST['yorum_id'];
	
	//Tablo güncelleme işlemi kodları...
	$yorumduzenle=$db->prepare("UPDATE yorumlar SET

		yorum_detay=:yorum_detay,


		yorum_durum=:durum
		where yorum_id={$_POST['yorum_id']} ");
	$update=$yorumduzenle->execute(array(

		'yorum_detay' => $_POST['yorum_detay'],
		
		
		'durum' => $_POST['yorum_durum']
	));


	if ($update) {

		header("Location:../production/yorum-duzenle.php?yorum_id=$yorum_id&duzenleme=ok");

	} else {

		header("Location:../production/yorum-duzenle.php?yorum_id=$yorum_id&duzenleme=no");
	}
	
}

if(@$_GET['yorumsil']=="ok"){
	$sil=$db->prepare("DELETE From yorumlar where yorum_id=:id");
	$kontrol=$sil->execute(array(
		'id'=> $_GET['yorum_id']
	));

	if ($kontrol) {

		header("Location:../production/yorumlar.php?sil=ok");

	} else {

		header("Location:../production/yorumlar.php?sil=no");
	}
	
}

if (isset($_POST['sepeteekle'])) {





	$sepetkaydet=$db->prepare("INSERT into sepet SET  

		
		urun_adet=:urun_adet,
		kullanici_id=:kullanici_id,
		urun_id=:urun_id
		
		");
	$insert=$sepetkaydet->execute(array(

		'urun_adet' =>$_POST['urun_adet'],
		'kullanici_id' =>$_POST['kullanici_id'],
		'urun_id' =>$_POST['urun_id'],

	));
	if ($insert) {
		header("Location:../../sepetim?durum=ok");
	} else {
		header("Location:../../sepetim?durum=no");
	}
} 

if (@$_GET['urun_onecikar']=="ok") {

	

	
	$duzenle=$db->prepare("UPDATE urun SET
		
		urun_onecikar=:urun_onecikar
		
		WHERE urun_id={$_GET['urun_id']}");
	
	$update=$duzenle->execute(array(


		'urun_onecikar' => $_GET['urun_one']
	));



	if ($update) {

		

		Header("Location:../production/urunler.php?durum=ok");

	} else {

		Header("Location:../production/urunler.php?durum=no");
	}

}

if (@$_GET['yorum_onay']=="ok") {

	

	
	$duzenle=$db->prepare("UPDATE yorumlar SET
		
		yorum_onay=:yorum_onay
		
		WHERE yorum_id={$_GET['yorum_id']}");
	
	$update=$duzenle->execute(array(


		'yorum_onay' => $_GET['yorum_on']
	));



	if ($update) {

		

		Header("Location:../production/yorum.php?durum=ok");

	} else {

		Header("Location:../production/yorum.php?durum=no");
	}

}


if (isset($_POST['bankakaydet'])) {
	
//Tablo güncelleme işlemi kodları...
	$bankakaydet=$db->prepare("INSERT into banka SET
		banka_ad=:ad,
		banka_iban=:iban,
		banka_hesapadsoyad=:banka_hesapadsoyad,
		banka_durum=:durum
		");
	$kaydet=$bankakaydet->execute(array(
		'ad' => $_POST['banka_ad'],
		'iban' => $_POST['banka_iban'],
		'banka_hesapadsoyad' => $_POST['banka_hesapadsoyad'],
		'durum' => $_POST['banka_durum']
	));


	if ($kaydet) {

		header("Location:../production/banka.php?ekle=ok");

	} else {

		header("Location:../production/banka-ekle.php?ekleme=basarısız");
	}

}



if (isset($_POST['bankaduzenle'])) {
	$banka_id=$_POST['banka_id'];
	
	$bankaduzenle=$db->prepare("UPDATE banka SET
		banka_ad=:ad,
		banka_iban=:banka_iban,
		banka_hesapadsoyad=:banka_hesapadsoyad,
		banka_durum=:durum
		where banka_id={$_POST['banka_id']} ");
	$update=$bankaduzenle->execute(array(
		'ad' => $_POST['banka_ad'],
		'banka_iban' => $_POST['banka_iban'],
		'banka_hesapadsoyad' => $_POST['banka_hesapadsoyad'],
		'durum' => $_POST['banka_durum']
	));


	if ($update) {

		header("Location:../production/banka-duzenle.php?banka_id=$banka_id&duzenleme=ok");

	} else {

		header("Location:../production/banka-duzenle.php?banka_id=$banka_id&duzenleme=no");
	}

}


if(@$_GET['bankasil']=="ok"){
	$sil=$db->prepare("DELETE From banka where banka_id=:id");
	$kontrol=$sil->execute(array(
		'id'=> $_GET['banka_id']
	));

	if ($kontrol) {

		header("Location:../production/banka.php?sil=ok");

	} else {

		header("Location:../production/banka.php?sil=no");
	}
	
}



if (isset($_POST['kullanicisifreguncelle'])) {

	echo $kullanici_eskipassword=trim($_POST['kullanici_eskipassword']); echo "<br>";
	echo $kullanici_passwordone=trim($_POST['kullanici_passwordone']); echo "<br>";
	echo $kullanici_passwordtwo=trim($_POST['kullanici_passwordtwo']); echo "<br>";

	$kullanici_password=md5($kullanici_eskipassword);


	$kullanicisor=$db->prepare("select * from kullanici where kullanici_password=:password");
	$kullanicisor->execute(array(
		'password' => $kullanici_password
	));

			//dönen satır sayısını belirtir
	$say=$kullanicisor->rowCount();



	if ($say==0) {

		header("Location:../../sifre-guncelle?durum=eskisifrehata");



	} else {



	//eski şifre doğruysa başla


		if ($kullanici_passwordone==$kullanici_passwordtwo) {


			if (strlen($kullanici_passwordone)>=6) {


				//md5 fonksiyonu şifreyi md5 şifreli hale getirir.
				$password=md5($kullanici_passwordone);

				$kullanici_yetki=1;

				$kullanicikaydet=$db->prepare("UPDATE kullanici SET
					kullanici_password=:kullanici_password
					WHERE kullanici_id={$_POST['kullanici_id']}");

				
				$insert=$kullanicikaydet->execute(array(
					'kullanici_password' => $password
				));

				if ($insert) {


					header("Location:../../sifre-guncelle.php?durum=sifredegisti");


				//Header("Location:../production/genel-ayarlar.php?durum=ok");

				} else {


					header("Location:../../sifre-guncelle.php?durum=no");
				}





		// Bitiş



			} else {


				header("Location:../../sifre-guncelle.php?durum=eksiksifre");


			}



		} else {

			header("Location:../../sifre-guncelle?durum=sifreleruyusmuyor");

			exit;


		}


	}

	exit;

	if ($update) {

		header("Location:../../sifre-guncelle?durum=ok");

	} else {

		header("Location:../../sifre-guncelle?durum=no");
	}

}



if (isset($_POST['bankasiparisekle'])) {


	$siparis_tip="Banka Havalesi";


	$kaydet=$db->prepare("INSERT INTO siparis SET
		kullanici_id=:kullanici_id,
		siparis_tip=:siparis_tip,	
		siparis_banka=:siparis_banka,
		siparis_toplam=:siparis_toplam
		");
	$insert=$kaydet->execute(array(
		'kullanici_id' => $_POST['kullanici_id'],
		'siparis_tip' => $siparis_tip,
		'siparis_banka' => $_POST['siparis_banka'],
		'siparis_toplam' => $_POST['siparis_toplam']		
	));

	if ($insert) {

		//Sipariş başarılı kaydedilirse...

		echo $siparis_id = $db->lastInsertId();

		echo "<hr>";


		$kullanici_id=$_POST['kullanici_id'];
		$sepetsor=$db->prepare("SELECT * FROM sepet where kullanici_id=:id");
		$sepetsor->execute(array(
			'id' => $kullanici_id
		));

		while($sepetcek=$sepetsor->fetch(PDO::FETCH_ASSOC)) {

			$urun_id=$sepetcek['urun_id']; 
			$urun_adet=$sepetcek['urun_adet'];

			$urunsor=$db->prepare("SELECT * FROM urun where urun_id=:id");
			$urunsor->execute(array(
				'id' => $urun_id
			));

			$uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
			
			echo $urun_fiyat=$uruncek['urun_fiyat'];


			
			$kaydet=$db->prepare("INSERT INTO siparis_detay SET
				
				siparis_id=:siparis_id,
				urun_id=:urun_id,	
				urun_fiyat=:urun_fiyat,
				urun_adet=:urun_adet
				");
			$insert=$kaydet->execute(array(
				'siparis_id' => $siparis_id,
				'urun_id' => $urun_id,
				'urun_fiyat' => $urun_fiyat,
				'urun_adet' => $urun_adet

			));


		}

		if ($insert) {

			

			//Sipariş detay kayıtta başarıysa sepeti boşalt

			$sil=$db->prepare("DELETE from sepet where kullanici_id=:kullanici_id");
			$kontrol=$sil->execute(array(
				'kullanici_id' => $kullanici_id
			));

			
			Header("Location:../../siparislerim?durum=ok");
			exit;


		}

		




	} else {

		echo "başarısız";

		//Header("Location:../production/siparis.php?durum=no");
	}



}



if(isset($_POST['urunfotosil'])) {

	$urun_id=$_POST['urun_id'];


	echo $checklist = $_POST['urunfotosec'];

	
	foreach($checklist as $list) {

		$sil=$db->prepare("DELETE from urunfoto where urunfoto_id=:urunfoto_id");
		$kontrol=$sil->execute(array(
			'urunfoto_id' => $list
		));
	}

	if ($kontrol) {

		Header("Location:../production/urun-galeri.php?urun_id=$urun_id&durum=ok");

	} else {

		Header("Location:../production/urun-galeri.php?urun_id=$urun_id&durum=no");
	}


} 
?>